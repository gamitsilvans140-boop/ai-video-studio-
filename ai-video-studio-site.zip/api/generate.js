// Vercel serverless function. Keeps the API key on the server.
const MODEL = 'claude-sonnet-5-5';
const MAX_PROMPT_CHARS = 14000;   // stops huge, costly requests
const LIMIT = 12;                 // requests per IP per hour (best effort, in-memory)
const WINDOW_MS = 60 * 60 * 1000;
const hits = new Map();

function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (arr.length >= LIMIT) { hits.set(ip, arr); return true; }
  arr.push(now); hits.set(ip, arr); return false;
}

function parseJson(text) {
  const clean = text.replace(/```json|```/g, '').trim();
  const start = clean.indexOf('{');
  const end = clean.lastIndexOf('}');
  return JSON.parse(clean.slice(start, end + 1));
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ code: 'method' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ code: 'no_key' });

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  if (limited(ip)) return res.status(429).json({ code: 'rate_limited' });

  const prompt = req.body && req.body.prompt;
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT_CHARS) {
    return res.status(400).json({ code: 'bad_prompt' });
  }

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    if (!r.ok) {
      const code = r.status === 429 ? 'rate_limited' : 'upstream';
      return res.status(r.status === 429 ? 429 : 502).json({ code });
    }
    const data = await r.json();
    const text = (data.content || []).map((c) => (c.type === 'text' ? c.text : '')).join('');
    return res.status(200).json({ result: parseJson(text) });
  } catch (e) {
    return res.status(502).json({ code: 'parse_or_network' });
  }
};
