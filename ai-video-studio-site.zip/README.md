# AI Video Studio - hosting guide (Vercel)

## Files
- index.html : poora frontend
- api/generate.js : server function (API key yahin safe rehti hai)
- robots.txt, sitemap.xml : Google ke liye
- vercel.json : function ka timeout

## Steps
1. GitHub par naya repo banao aur ye saari files upload karo.
2. vercel.com par GitHub se login karo, "Add New > Project", us repo ko import karo, Deploy dabao.
3. Vercel me Project > Settings > Environment Variables me ANTHROPIC_API_KEY naam se apni key daalo
   (key console.anthropic.com se banti hai). Phir Redeploy karo.
4. Anthropic console me monthly spend limit zaroor lagao, taaki bill control me rahe.
5. Apna domain lo, Vercel me Project > Settings > Domains me jodo.
6. index.html, robots.txt aur sitemap.xml me YOUR-DOMAIN.com ko apne asli domain se badlo.
7. search.google.com/search-console par site add karo aur sitemap.xml submit karo.

## Dhyan rakho
- API ke har use par paisa lagta hai.
- api/generate.js me per-IP limit hai (12 per ghanta), par ye basic hai. Zyada traffic aaye to login ya
  behtar rate limiting jodo.
- Is page ko "AI generated" ya jo bhi policy platforms ki ho, uske hisaab se use karo.
